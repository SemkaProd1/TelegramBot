package org.altervista.leocus.telegrambotutilities;

public class UnsupportedFileTypeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
