package org.altervista.leocus.telegrambotutilities;

import org.json.JSONObject;

public interface InputMessageContent {

	public JSONObject toJSONObject();

}
