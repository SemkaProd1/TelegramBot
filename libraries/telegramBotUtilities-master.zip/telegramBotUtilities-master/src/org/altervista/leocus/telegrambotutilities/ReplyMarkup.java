package org.altervista.leocus.telegrambotutilities;

public interface ReplyMarkup {
	public String toJSONString();
}
